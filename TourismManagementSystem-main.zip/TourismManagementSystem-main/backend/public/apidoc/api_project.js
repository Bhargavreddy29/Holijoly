define({
  name: "Tourism Management System",
  version: "1.0.0",
  description: "",
  sampleUrl: false,
  defaultVersion: "0.0.0",
  apidoc: "0.3.0",
  generator: {
    name: "apidoc",
    time: "2021-10-12T10:39:37.830Z",
    url: "https://apidocjs.com",
    version: "0.29.0",
  },
});
