import React from "react";

const Admin = () => {
  return <div></div>;
};

export default Admin;
