import React, { createContext } from "react";
const orderContext = createContext();
export default orderContext;
