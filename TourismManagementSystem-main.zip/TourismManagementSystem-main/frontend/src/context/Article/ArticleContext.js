import React, { createContext } from "react";
const ArticleContext = createContext();
export default ArticleContext;
